# MENU x CHR iOS Project

Project này đã được cấu hình sẵn để đóng gói thành app iOS từ file index.html bạn gửi.

## Cấu trúc
- www/index.html  → Giao diện HTML
- config.xml      → Cấu hình Cordova (Bundle ID, tên app...)

## Hướng dẫn build ra .ipa chưa ký
1. Nén toàn bộ thư mục này lại (.zip)
2. Upload lên dịch vụ build iOS như codemagic.io hoặc ionic.io/appflow
3. Chọn build "Unsigned IPA"
4. Tải file .ipa về iPhone và ký chứng chỉ bằng AltStore hoặc công cụ của bạn.

Bundle ID hiện tại: com.example.menuxchr
Tên hiển thị: MENU x CHR
